create database escritorio;

use escritorio;

create table cliente(
idcliente integer primary key auto_increment,
nome varchar(60)not null,
telefone varchar(14)not null);

insert into cliente(nome, telefone)values
('Maria Fernanda', '(21)99985-1414'),
('Pedro da Silva', '(21)94002-8922');

select * from cliente;

create table advogado(
oab integer primary key,
nome varchar(60)not null,
telefone varchar(14)not null,
tipocausas varchar(60)not null);

insert into advogado(oab, nome, telefone,tipocausas)values
('25625','Maria Fernanda', '(21)99985-1414', 'trabalhista');

select * from advogado;
