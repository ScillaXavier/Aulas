package Model;

public class Cliente {
    private int IdCliente;
    private String Nome;
    private String Telefone;
    private String Cpf;
    private String Rg;
    
	public Cliente(int idCliente, String nome, String telefone, String cpf, String rg) {
		super();
		IdCliente = idCliente;
		Nome = nome;
		Telefone = telefone;
		Cpf = cpf;
		Rg = rg;
	}

	public int getIdCliente() {
		return IdCliente;
	}

	public void setIdCliente(int idCliente) {
		IdCliente = idCliente;
	}

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public String getTelefone() {
		return Telefone;
	}

	public void setTelefone(String telefone) {
		Telefone = telefone;
	}

	public String getCpf() {
		return Cpf;
	}

	public void setCpf(String cpf) {
		Cpf = cpf;
	}

	public String getRg() {
		return Rg;
	}

	public void setRg(String rg) {
		Rg = rg;
	}
    
	
	
    
    
}
