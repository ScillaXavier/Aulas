package Model;

public class Causas {
	
	private int IdCausa;
	private int Tipo;
    
	
		
	public Causas(int idCausa, int tipo) {
		super();
		IdCausa = idCausa;
		Tipo = tipo;
		
	}
	
	
	public int getIdCausa() {
		return IdCausa;
	}
	public void setIdCausa(int idCausa) {
		IdCausa = idCausa;
	}
	public int getTipo() {
		return Tipo;
	}


	public void setTipo(int tipo) {
		Tipo = tipo;
	}
	
	}


